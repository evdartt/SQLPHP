<?php
$con=mysqli_connect("db.sice.indiana.edu","i308s19_team61","my+sql=i308s19_team61","i308s19_team61");
// Check connection
if (mysqli_connect_errno())
{echo nl2br("Failed to connect to MySQL: " . mysqli_connect_error() . "\n "); }
else 
{echo nl2br("Established Database Connection \n");}

//select statement pulling data from album and band tables - need band table because the band name should be returned not the bid
$sql='SELECT f.FacultyID, CONCAT(f.fName, " ",f.lName) AS name 
FROM tp_Faculty as f
WHERE NOT EXISTS (
	SELECT *
	FROM tp_Section as se, tp_Course as c
	WHERE f.FacultyID = f.SectionID
	AND se.CourseNumber = c.CourseNumber
	AND c.CourseNumber LIKE "'. $_POST['form-CourseNumber'] .'");';



$result = mysqli_query($con, $sql); 
//set up the table with Headers
if (mysqli_num_rows($result) > 0) {
	echo "<table border='3'><tr><th>FacultyID</th><th>Name</th></tr>";

//if the sql query results in a number of rows greater than 0, then insert the data into a table; else, return 0 results
	while ($row = mysqli_fetch_assoc($result)) {
	echo
//for each row of data, add the appropriate columns data to the row - format as html		
"<tr><td>".$row['FacultyID']."</td><td>".$row['name'] ."</td></tr>";
    }
	echo "</table>";
} 
mysqli_close($con);
?>