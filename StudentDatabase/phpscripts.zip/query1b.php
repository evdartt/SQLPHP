<?php
$con=mysqli_connect("db.sice.indiana.edu","i308s19_team61","my+sql=i308s19_team61","i308s19_team61");
// Check connection
if (mysqli_connect_errno())
{echo nl2br("Failed to connect to MySQL: " . mysqli_connect_error() . "\n "); }
else 
{echo nl2br("Established Database Connection \n");}

//select statement pulling data from album and band tables - need band table because the band name should be returned not the bid
$sql="SELECT se.SectionID, CONCAT(st.lName,',  ',st.fName) as name, sd.LetterGrade
FROM tp_Student as st, tp_Section_details as sd,  gpa_chart as gpa, tp_Section as se
WHERE sd.sid = st.sid
AND sd.SectionID = se.SectionID
AND sd.LetterGrade=gpa.LetterGrade
AND se.SectionID = ". $_POST['SectionID'] ."
UNION
SELECT se.SectionID, 'Average Grade', AVG(gpa.GradePoints)
FROM tp_Student as st, tp_Section_details as sd,  gpa_chart as gpa, tp_Section as se
WHERE sd.sid = st.sid
AND sd.SectionID = se.SectionID
AND sd.LetterGrade=gpa.LetterGrade
AND se.SectionID = " . $_POST['SectionID'] . ";";

$result = mysqli_query($con, $sql); 
//set up the table with Headers
echo "<table border='3'><tr><th>SectionID</th><th>Name</th><th>LetterGrade</th></tr>";

//if the sql query results in a number of rows greater than 0, then insert the data into a table; else, return 0 results
while ($row = mysqli_fetch_assoc($result)) {
	echo
//for each row of data, add the appropriate columns data to the row - format as html		
"<tr><td>".$row["SectionID"]."</td><td>".$row["name"]."</td><td>".$row["LetterGrade"]."</td></tr>";
    }
echo "</table>";

mysqli_close($con);
?>