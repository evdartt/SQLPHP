<?php
$con=mysqli_connect("db.sice.indiana.edu","i308s19_team61","my+sql=i308s19_team61","i308s19_team61");
// Check connection
if (mysqli_connect_errno())
{echo nl2br("Failed to connect to MySQL: " . mysqli_connect_error() . "\n "); }
else 
{echo nl2br("Established Database Connection \n");}

//select statement pulling data from album and band tables - need band table because the band name should be returned not the bid
$sql="SELECT CONCAT(st.fName, ' ' , st.lName) as name, m.Title as Major, SUM(c.CreditHr) as hours_earned, ( SUM(gpa.GradePoints* c.CreditHr)/ SUM(c.CreditHr)) as Overall_GPA
FROM tp_Student as st, tp_Major as m, tp_Course as c, gpa_chart as gpa, tp_Student_Major as sm, tp_Section_details as sd, tp_Section as sec
WHERE st.sid = sm.sid
AND m.MajorID = sm.MajorID
AND st.sid = sd.sid
AND c.CourseNumber = sec.CourseNumber
AND sec.SectionID = sd.SectionID
AND sd.LetterGrade=gpa.LetterGrade
GROUP BY Major, name, m.Required_Credit_Hours, m.RequiredGPA
HAVING SUM(c.CreditHr) >= m.Required_Credit_Hours
AND Overall_GPA >= m.RequiredGPA;
";


$result = mysqli_query($con, $sql); 
//set up the table with Headers
if (mysqli_num_rows($result) > 0) {
	echo "<table border='3'><tr><th>Name</th><th>Major</th><th>hours_earned</th><th>Overall_GPA</th></tr>";

//if the sql query results in a number of rows greater than 0, then insert the data into a table; else, return 0 results
	while ($row = mysqli_fetch_assoc($result)) {
	echo
//for each row of data, add the appropriate columns data to the row - format as html		
"<tr><td>".$row["name"]."</td><td>".$row["Major"]."</td><td>".$row["hours_earned"]."</td><td>".$row["Overall_GPA"]."</td></tr>";
    }
	echo "</table>";
}
mysqli_close($con);
?>