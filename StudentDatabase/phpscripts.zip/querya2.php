<html>
<body>
<form action="addquery2.php" method="post">
<p><h3>Displays students with last name starting with 'D', their advisor and advisor's expertise.
</h3></p>

<?php
$con = mysqli_connect("db.sice.indiana.edu","i308s19_team61","my+sql=i308s19_team61","i308s19_team61");

$sql = "SELECT st.sid as StudentID, CONCAT(st.fName, ' ' ,st.lName) as Student, CONCAT(a.fName, ' ' ,a.lName) as Advisor, aex.Expertise as Expertise FROM tp_Advisor as a, tp_Advisor_expertise as aex, tp_Student as st WHERE st.AdvisorID = a.AdvisorID AND a.AdvisorID = aex.AdvisorID AND st.lName LIKE 'D%' ORDER BY st.sid;";

$results = mysqli_query($con, $sql);

if (mysqli_num_rows($results) > 0) {
	echo "<table border='1'><tr><th>StudentID</th><th>Student</th><th>Advisor</th><th>Expertise</th></tr>";
	// output data of each row
    while($row = mysqli_fetch_array($results)) {
        echo "<tr><td>".$row["StudentID"]."</td><td>".$row["Student"]."</td><td>".$row["Advisor"]."</td><td>".$row["Expertise"]."</td></tr>";	
	}
	echo "</table>";
} else {
	echo "0 results";
}

mysqli_close($con);

?>
